import { rgbToHsl, hslToRgb } from './colorUtils';

// Apply image adjustments (brightness, contrast, saturation, hue)
export function applyImageAdjustments(image, adjustments) {
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');
  
  canvas.width = image.width;
  canvas.height = image.height;
  ctx.drawImage(image, 0, 0);
  
  const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
  const data = imageData.data;
  
  const brightness = adjustments.brightness / 100;
  const contrast = (adjustments.contrast + 100) / 100;
  const saturation = (adjustments.saturation + 100) / 100;
  const hue = adjustments.hue;
  
  for (let i = 0; i < data.length; i += 4) {
    let r = data[i];
    let g = data[i + 1];
    let b = data[i + 2];
    
    // Apply brightness
    r += brightness * 255;
    g += brightness * 255;
    b += brightness * 255;
    
    // Apply contrast
    r = ((r / 255 - 0.5) * contrast + 0.5) * 255;
    g = ((g / 255 - 0.5) * contrast + 0.5) * 255;
    b = ((b / 255 - 0.5) * contrast + 0.5) * 255;
    
    // Convert to HSL for saturation and hue
    const hsl = rgbToHsl(r, g, b);
    hsl.s = Math.max(0, Math.min(1, hsl.s * saturation));
    hsl.h = (hsl.h + hue / 360) % 1;
    if (hsl.h < 0) hsl.h += 1;
    
    // Convert back to RGB
    const rgb = hslToRgb(hsl.h, hsl.s, hsl.l);
    
    data[i] = Math.max(0, Math.min(255, rgb.r));
    data[i + 1] = Math.max(0, Math.min(255, rgb.g));
    data[i + 2] = Math.max(0, Math.min(255, rgb.b));
  }
  
  ctx.putImageData(imageData, 0, 0);
  return canvas;
}
