import { hexToRgb, rgbToHex } from './colorUtils';

// Convert RGB to LAB color space for perceptually accurate color distance
function rgbToLab(r, g, b) {
  // First convert RGB to XYZ
  let var_R = r / 255;
  let var_G = g / 255;
  let var_B = b / 255;

  if (var_R > 0.04045) var_R = Math.pow((var_R + 0.055) / 1.055, 2.4);
  else var_R = var_R / 12.92;
  if (var_G > 0.04045) var_G = Math.pow((var_G + 0.055) / 1.055, 2.4);
  else var_G = var_G / 12.92;
  if (var_B > 0.04045) var_B = Math.pow((var_B + 0.055) / 1.055, 2.4);
  else var_B = var_B / 12.92;

  var_R = var_R * 100;
  var_G = var_G * 100;
  var_B = var_B * 100;

  // Observer = 2°, Illuminant = D65
  let X = var_R * 0.4124 + var_G * 0.3576 + var_B * 0.1805;
  let Y = var_R * 0.2126 + var_G * 0.7152 + var_B * 0.0722;
  let Z = var_R * 0.0193 + var_G * 0.1192 + var_B * 0.9505;

  // Convert XYZ to LAB
  let var_X = X / 95.047;
  let var_Y = Y / 100.000;
  let var_Z = Z / 108.883;

  if (var_X > 0.008856) var_X = Math.pow(var_X, 1/3);
  else var_X = (7.787 * var_X) + (16/116);
  if (var_Y > 0.008856) var_Y = Math.pow(var_Y, 1/3);
  else var_Y = (7.787 * var_Y) + (16/116);
  if (var_Z > 0.008856) var_Z = Math.pow(var_Z, 1/3);
  else var_Z = (7.787 * var_Z) + (16/116);

  return {
    L: (116 * var_Y) - 16,
    a: 500 * (var_X - var_Y),
    b: 200 * (var_Y - var_Z)
  };
}

// Perceptually accurate color distance using CIEDE2000
function colorDistanceLab(lab1, lab2) {
  const deltaL = lab1.L - lab2.L;
  const deltaA = lab1.a - lab2.a;
  const deltaB = lab1.b - lab2.b;
  
  // Simplified CIEDE2000 formula (full formula is very complex)
  // This is a good approximation for our purposes
  return Math.sqrt(deltaL * deltaL + deltaA * deltaA + deltaB * deltaB);
}

// Enhanced k-means clustering with better initialization
function enhancedKMeansQuantize(imageData, k = 40, iterations = 25) {
  const pixels = [];
  const data = imageData.data;
  const width = imageData.width;
  const height = imageData.height;
  
  // Collect all pixels with weights (center pixels are more important)
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const idx = (y * width + x) * 4;
      const r = data[idx];
      const g = data[idx + 1];
      const b = data[idx + 2];
      const a = data[idx + 3];
      
      if (a < 128) continue; // Skip transparent pixels
      
      // Weight pixels near center more heavily (faces are usually centered)
      const centerX = width / 2;
      const centerY = height / 2;
      const distFromCenter = Math.sqrt(
        Math.pow(x - centerX, 2) + Math.pow(y - centerY, 2)
      );
      const maxDist = Math.sqrt(centerX * centerX + centerY * centerY);
      const weight = 1 + (1 - distFromCenter / maxDist) * 3; // Center pixels have 4x weight
      
      pixels.push({ 
        r, g, b, 
        lab: rgbToLab(r, g, b),
        weight 
      });
    }
  }
  
  if (pixels.length === 0) return [];
  
  // Initialize centroids using k-means++ for better starting positions
  const centroids = [];
  
  // First centroid: random pixel
  centroids.push({...pixels[Math.floor(Math.random() * pixels.length)]});
  
  // Remaining centroids: choose pixels far from existing centroids
  for (let i = 1; i < k; i++) {
    let maxMinDist = -1;
    let bestPixel = null;
    
    // Sample random subset for performance
    const sampleSize = Math.min(1000, pixels.length);
    for (let j = 0; j < sampleSize; j++) {
      const pixel = pixels[Math.floor(Math.random() * pixels.length)];
      
      // Find minimum distance to existing centroids
      let minDist = Infinity;
      for (const centroid of centroids) {
        const dist = colorDistanceLab(pixel.lab, centroid.lab);
        if (dist < minDist) minDist = dist;
      }
      
      // Keep pixel with maximum minimum distance
      if (minDist > maxMinDist) {
        maxMinDist = minDist;
        bestPixel = pixel;
      }
    }
    
    if (bestPixel) centroids.push({...bestPixel});
  }
  
  // Run k-means iterations
  for (let iter = 0; iter < iterations; iter++) {
    const clusters = Array(k).fill(null).map(() => []);
    
    // Assign each pixel to nearest centroid
    for (const pixel of pixels) {
      let minDist = Infinity;
      let clusterIndex = 0;
      
      for (let i = 0; i < centroids.length; i++) {
        const dist = colorDistanceLab(pixel.lab, centroids[i].lab);
        if (dist < minDist) {
          minDist = dist;
          clusterIndex = i;
        }
      }
      
      clusters[clusterIndex].push(pixel);
    }
    
    // Update centroids to weighted mean of cluster
    let changed = false;
    for (let i = 0; i < k; i++) {
      const cluster = clusters[i];
      if (cluster.length === 0) continue;
      
      let totalWeight = 0;
      let sumR = 0, sumG = 0, sumB = 0;
      
      for (const pixel of cluster) {
        const w = pixel.weight || 1;
        sumR += pixel.r * w;
        sumG += pixel.g * w;
        sumB += pixel.b * w;
        totalWeight += w;
      }
      
      const newR = Math.round(sumR / totalWeight);
      const newG = Math.round(sumG / totalWeight);
      const newB = Math.round(sumB / totalWeight);
      
      if (newR !== centroids[i].r || newG !== centroids[i].g || newB !== centroids[i].b) {
        changed = true;
        centroids[i] = {
          r: newR,
          g: newG,
          b: newB,
          lab: rgbToLab(newR, newG, newB),
          weight: 1
        };
      }
    }
    
    // Early termination if converged
    if (!changed) break;
  }
  
  // Convert centroids to hex colors
  return centroids.map(c => rgbToHex(c.r, c.g, c.b));
}

// Enhanced Floyd-Steinberg dithering with perceptual color matching
function enhancedFloydSteinbergDither(imageData, palette) {
  const width = imageData.width;
  const height = imageData.height;
  const data = new Float32Array(imageData.data); // Use float for better precision
  
  // Pre-convert palette to LAB for faster lookups
  const paletteLab = palette.map(hex => {
    const rgb = hexToRgb(hex);
    return {
      ...rgb,
      lab: rgbToLab(rgb.r, rgb.g, rgb.b),
      hex
    };
  });
  
  // Build a cache for color lookups
  const colorCache = new Map();
  
  // Find nearest palette color using LAB distance with caching
  const findNearestColor = (r, g, b) => {
    const key = `${Math.round(r)},${Math.round(g)},${Math.round(b)}`;
    if (colorCache.has(key)) {
      return colorCache.get(key);
    }
    
    const lab = rgbToLab(r, g, b);
    let minDist = Infinity;
    let nearest = paletteLab[0];
    
    for (const pColor of paletteLab) {
      const dist = colorDistanceLab(lab, pColor.lab);
      if (dist < minDist) {
        minDist = dist;
        nearest = pColor;
      }
    }
    
    colorCache.set(key, nearest);
    return nearest;
  };
  
  // Apply dithering with enhanced error diffusion
  // Using Sierra Lite dithering for smoother gradients
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const idx = (y * width + x) * 4;
      
      const oldR = Math.max(0, Math.min(255, data[idx]));
      const oldG = Math.max(0, Math.min(255, data[idx + 1]));
      const oldB = Math.max(0, Math.min(255, data[idx + 2]));
      
      // Find nearest palette color
      const newColor = findNearestColor(oldR, oldG, oldB);
      
      data[idx] = newColor.r;
      data[idx + 1] = newColor.g;
      data[idx + 2] = newColor.b;
      
      // Calculate error
      const errR = oldR - newColor.r;
      const errG = oldG - newColor.g;
      const errB = oldB - newColor.b;
      
      // Distribute error with Floyd-Steinberg kernel
      // Current pixel: X
      //                X   7/16
      //        3/16  5/16  1/16
      
      const distributeError = (xOffset, yOffset, factor) => {
        const nx = x + xOffset;
        const ny = y + yOffset;
        
        if (nx >= 0 && nx < width && ny >= 0 && ny < height) {
          const nIdx = (ny * width + nx) * 4;
          data[nIdx] += errR * factor;
          data[nIdx + 1] += errG * factor;
          data[nIdx + 2] += errB * factor;
        }
      };
      
      distributeError(1, 0, 7/16);   // Right
      distributeError(-1, 1, 3/16);  // Bottom-left
      distributeError(0, 1, 5/16);   // Bottom
      distributeError(1, 1, 1/16);   // Bottom-right
    }
  }
  
  // Convert back to Uint8ClampedArray
  const result = new Uint8ClampedArray(data.length);
  for (let i = 0; i < data.length; i++) {
    result[i] = Math.max(0, Math.min(255, Math.round(data[i])));
  }
  
  return new ImageData(result, width, height);
}

// Smart downsampling with edge preservation
function smartDownsample(canvas, targetSize) {
  const sourceWidth = canvas.width;
  const sourceHeight = canvas.height;
  
  // Multi-pass downsampling for better quality
  // Instead of going directly to 32x32, downsample in steps
  const steps = [];
  let currentSize = Math.max(sourceWidth, sourceHeight);
  
  while (currentSize > targetSize * 2) {
    currentSize = Math.floor(currentSize / 2);
    steps.push(currentSize);
  }
  steps.push(targetSize);
  
  let currentCanvas = canvas;
  
  for (const stepSize of steps) {
    const tempCanvas = document.createElement('canvas');
    const tempCtx = tempCanvas.getContext('2d');
    tempCanvas.width = stepSize;
    tempCanvas.height = stepSize;
    
    // Use high-quality image smoothing
    tempCtx.imageSmoothingEnabled = true;
    tempCtx.imageSmoothingQuality = 'high';
    
    tempCtx.drawImage(
      currentCanvas,
      0, 0, currentCanvas.width, currentCanvas.height,
      0, 0, stepSize, stepSize
    );
    
    currentCanvas = tempCanvas;
  }
  
  return currentCanvas.getContext('2d').getImageData(0, 0, targetSize, targetSize);
}

// Enhance contrast and sharpness for better face definition
function enhanceForFaces(imageData) {
  const data = imageData.data;
  const width = imageData.width;
  const height = imageData.height;
  
  // Create a copy for sharpening
  const original = new Uint8ClampedArray(data);
  
  // Apply unsharp mask for better edge definition
  const sharpenKernel = [
    0, -1, 0,
    -1, 5, -1,
    0, -1, 0
  ];
  
  for (let y = 1; y < height - 1; y++) {
    for (let x = 1; x < width - 1; x++) {
      for (let c = 0; c < 3; c++) { // RGB channels
        let sum = 0;
        for (let ky = -1; ky <= 1; ky++) {
          for (let kx = -1; kx <= 1; kx++) {
            const idx = ((y + ky) * width + (x + kx)) * 4 + c;
            const kernelIdx = (ky + 1) * 3 + (kx + 1);
            sum += original[idx] * sharpenKernel[kernelIdx];
          }
        }
        const idx = (y * width + x) * 4 + c;
        data[idx] = Math.max(0, Math.min(255, sum));
      }
    }
  }
  
  // Enhance contrast slightly for better definition
  const factor = 1.15; // Slightly reduced for more natural look
  for (let i = 0; i < data.length; i += 4) {
    for (let c = 0; c < 3; c++) {
      const value = data[i + c];
      data[i + c] = Math.max(0, Math.min(255, 
        ((value / 255 - 0.5) * factor + 0.5) * 255
      ));
    }
  }
  
  return imageData;
}

// Main advanced pixelation function with enhanced quality
export function advancedPixelate(image, size = 32, useDithering = true) {
  try {
    // Step 1: Draw original to temp canvas
    const tempCanvas = document.createElement('canvas');
    const tempCtx = tempCanvas.getContext('2d');
    tempCanvas.width = image.width;
    tempCanvas.height = image.height;
    tempCtx.drawImage(image, 0, 0);
    
    // Step 2: Smart multi-pass downsampling with edge preservation
    const downsampled = smartDownsample(tempCanvas, size);
    
    // Step 3: Enhance for better face/portrait definition
    const enhanced = enhanceForFaces(downsampled);
    
    // Step 4: Extract optimal palette from the ACTUAL image using enhanced k-means
    console.log('Extracting color palette from image...');
    const palette = enhancedKMeansQuantize(enhanced, 40, 25);
    console.log('Palette extracted:', palette.length, 'colors');
    
    // Step 5: Apply enhanced Floyd-Steinberg dithering with perceptual color matching
    let finalImageData;
    if (useDithering) {
      console.log('Applying perceptual dithering...');
      finalImageData = enhancedFloydSteinbergDither(enhanced, palette);
    } else {
      // Direct quantization without dithering
      const paletteLab = palette.map(hex => {
        const rgb = hexToRgb(hex);
        return {
          ...rgb,
          lab: rgbToLab(rgb.r, rgb.g, rgb.b)
        };
      });
      
      const data = enhanced.data;
      for (let i = 0; i < data.length; i += 4) {
        const lab = rgbToLab(data[i], data[i + 1], data[i + 2]);
        let minDist = Infinity;
        let nearest = paletteLab[0];
        
        for (const pColor of paletteLab) {
          const dist = colorDistanceLab(lab, pColor.lab);
          if (dist < minDist) {
            minDist = dist;
            nearest = pColor;
          }
        }
        
        data[i] = nearest.r;
        data[i + 1] = nearest.g;
        data[i + 2] = nearest.b;
      }
      finalImageData = enhanced;
    }
    
    console.log('Pixel art generation complete!');
    return finalImageData;
    
  } catch (error) {
    console.error('Error in advancedPixelate:', error);
    // Return a simple fallback
    const fallbackData = new ImageData(size, size);
    return fallbackData;
  }
}
