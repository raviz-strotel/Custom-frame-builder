import React, { useRef } from 'react';
import { Upload, Image as ImageIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function UploadZone({ onImageUpload }) {
  const fileInputRef = useRef(null);

  const handleFileChange = (e) => {
    const file = e.target.files?.[0];
    if (file && file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const img = new Image();
        img.onload = () => onImageUpload(img);
        img.src = event.target.result;
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (file && file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const img = new Image();
        img.onload = () => onImageUpload(img);
        img.src = event.target.result;
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDragOver = (e) => {
    e.preventDefault();
  };

  return (
    <div 
      data-testid="upload-zone"
      className="flex flex-col items-center justify-center p-12 border-2 border-dashed border-border rounded-xl bg-white hover:bg-background-secondary transition-colors cursor-pointer"
      onClick={() => fileInputRef.current?.click()}
      onDrop={handleDrop}
      onDragOver={handleDragOver}
    >
      <div className="w-20 h-20 rounded-full bg-accent/10 flex items-center justify-center mb-4">
        <Upload className="w-10 h-10 text-accent" />
      </div>
      
      <h3 className="text-xl font-semibold text-text-primary mb-2">Upload an Image</h3>
      <p className="text-text-secondary mb-1">Drag and drop or click to browse</p>
      <p className="text-sm text-text-muted mb-6">Supported formats: JPG, PNG, GIF, WebP, BMP</p>
      
      <Button 
        data-testid="browse-btn"
        variant="outline" 
        className="gap-2"
        onClick={(e) => {
          e.stopPropagation();
          fileInputRef.current?.click();
        }}
      >
        <ImageIcon className="w-4 h-4" />
        Browse Files
      </Button>
      
      <input
        data-testid="file-input"
        ref={fileInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={handleFileChange}
      />
    </div>
  );
}
