import React, { useState, useEffect, useRef } from 'react';

export default function PlainCropper({ image, cropBox, onCropBoxChange, visible }) {
  const [imageDimensions, setImageDimensions] = useState({ width: 0, height: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [isResizing, setIsResizing] = useState(false);
  const [resizeHandle, setResizeHandle] = useState(null);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const imageRef = useRef(null);

  // Initialize crop box when image loads
  const handleImageLoad = (e) => {
    const img = e.target;
    const containerWidth = Math.min(600, window.innerWidth - 64);
    const imgAspect = img.naturalWidth / img.naturalHeight;
    
    let displayWidth, displayHeight;
    if (imgAspect > 1) {
      displayWidth = containerWidth;
      displayHeight = containerWidth / imgAspect;
    } else {
      displayHeight = containerWidth;
      displayWidth = containerWidth * imgAspect;
    }
    
    setImageDimensions({ width: displayWidth, height: displayHeight });
    
    // Initialize centered square crop box
    const size = Math.min(displayWidth, displayHeight) * 0.6;
    onCropBoxChange({
      x: (displayWidth - size) / 2,
      y: (displayHeight - size) / 2,
      width: size,
      height: size
    }, { width: displayWidth, height: displayHeight });
  };

  // Get mouse/touch position
  const getPosition = (e) => {
    if (e.touches && e.touches.length > 0) {
      const rect = imageRef.current?.getBoundingClientRect();
      return {
        x: e.touches[0].clientX - (rect?.left || 0),
        y: e.touches[0].clientY - (rect?.top || 0)
      };
    }
    const rect = imageRef.current?.getBoundingClientRect();
    return {
      x: e.clientX - (rect?.left || 0),
      y: e.clientY - (rect?.top || 0)
    };
  };

  // Check if position is on a corner handle
  const getHandleAtPosition = (x, y) => {
    const handleSize = 20;
    const corners = [
      { name: 'tl', x: cropBox.x, y: cropBox.y },
      { name: 'tr', x: cropBox.x + cropBox.width, y: cropBox.y },
      { name: 'bl', x: cropBox.x, y: cropBox.y + cropBox.height },
      { name: 'br', x: cropBox.x + cropBox.width, y: cropBox.y + cropBox.height }
    ];

    for (const corner of corners) {
      const distance = Math.sqrt(
        Math.pow(x - corner.x, 2) + Math.pow(y - corner.y, 2)
      );
      if (distance <= handleSize) {
        return corner.name;
      }
    }
    return null;
  };

  // Check if position is inside crop box
  const isInsideCropBox = (x, y) => {
    return x >= cropBox.x && x <= cropBox.x + cropBox.width &&
           y >= cropBox.y && y <= cropBox.y + cropBox.height;
  };

  const handleMouseDown = (e) => {
    e.preventDefault();
    const pos = getPosition(e);
    const handle = getHandleAtPosition(pos.x, pos.y);

    if (handle) {
      setIsResizing(true);
      setResizeHandle(handle);
      setDragStart(pos);
    } else if (isInsideCropBox(pos.x, pos.y)) {
      setIsDragging(true);
      setDragStart({ x: pos.x - cropBox.x, y: pos.y - cropBox.y });
    }
  };

  const handleMouseMove = (e) => {
    if (!isDragging && !isResizing) return;
    e.preventDefault();

    const pos = getPosition(e);

    if (isDragging) {
      // Move crop box
      let newX = pos.x - dragStart.x;
      let newY = pos.y - dragStart.y;

      // Constrain within image bounds
      newX = Math.max(0, Math.min(newX, imageDimensions.width - cropBox.width));
      newY = Math.max(0, Math.min(newY, imageDimensions.height - cropBox.height));

      onCropBoxChange({
        ...cropBox,
        x: newX,
        y: newY
      }, imageDimensions);
    } else if (isResizing && resizeHandle) {
      // Resize crop box (maintain square aspect ratio)
      let newBox = { ...cropBox };

      switch (resizeHandle) {
        case 'tl': {
          const deltaX = pos.x - dragStart.x;
          const deltaY = pos.y - dragStart.y;
          const delta = Math.max(deltaX, deltaY);
          
          newBox.x = cropBox.x + delta;
          newBox.y = cropBox.y + delta;
          newBox.width = cropBox.width - delta;
          newBox.height = cropBox.height - delta;
          break;
        }
        case 'tr': {
          const deltaX = pos.x - dragStart.x;
          const deltaY = pos.y - dragStart.y;
          const delta = Math.max(deltaX, -deltaY);
          
          newBox.y = cropBox.y - delta;
          newBox.width = cropBox.width + delta;
          newBox.height = cropBox.height + delta;
          break;
        }
        case 'bl': {
          const deltaX = pos.x - dragStart.x;
          const deltaY = pos.y - dragStart.y;
          const delta = Math.max(-deltaX, deltaY);
          
          newBox.x = cropBox.x - delta;
          newBox.width = cropBox.width + delta;
          newBox.height = cropBox.height + delta;
          break;
        }
        case 'br': {
          const deltaX = pos.x - dragStart.x;
          const deltaY = pos.y - dragStart.y;
          const delta = Math.max(deltaX, deltaY);
          
          newBox.width = cropBox.width + delta;
          newBox.height = cropBox.height + delta;
          break;
        }
      }

      // Enforce minimum size
      const minSize = 50;
      if (newBox.width < minSize || newBox.height < minSize) {
        return;
      }

      // Constrain within image bounds
      if (newBox.x < 0) {
        newBox.width += newBox.x;
        newBox.height += newBox.x;
        newBox.x = 0;
      }
      if (newBox.y < 0) {
        newBox.width += newBox.y;
        newBox.height += newBox.y;
        newBox.y = 0;
      }
      if (newBox.x + newBox.width > imageDimensions.width) {
        const excess = (newBox.x + newBox.width) - imageDimensions.width;
        newBox.width -= excess;
        newBox.height -= excess;
      }
      if (newBox.y + newBox.height > imageDimensions.height) {
        const excess = (newBox.y + newBox.height) - imageDimensions.height;
        newBox.width -= excess;
        newBox.height -= excess;
      }

      setDragStart(pos);
      onCropBoxChange(newBox, imageDimensions);
    }
  };

  const handleMouseUp = () => {
    setIsDragging(false);
    setIsResizing(false);
    setResizeHandle(null);
  };

  useEffect(() => {
    if (isDragging || isResizing) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
      window.addEventListener('touchmove', handleMouseMove);
      window.addEventListener('touchend', handleMouseUp);

      return () => {
        window.removeEventListener('mousemove', handleMouseMove);
        window.removeEventListener('mouseup', handleMouseUp);
        window.removeEventListener('touchmove', handleMouseMove);
        window.removeEventListener('touchend', handleMouseUp);
      };
    }
  }, [isDragging, isResizing, cropBox, dragStart, resizeHandle]);

  if (!visible) {
    return (
      <div className="relative mx-auto" style={{ maxWidth: '600px' }}>
        <img
          ref={imageRef}
          src={image.src}
          alt="Original"
          onLoad={handleImageLoad}
          className="w-full h-auto"
          style={{ maxWidth: '600px' }}
        />
      </div>
    );
  }

  return (
    <div className="relative mx-auto" style={{ maxWidth: '600px' }}>
      <div 
        ref={imageRef}
        className="relative"
        style={{ 
          width: imageDimensions.width || 'auto',
          height: imageDimensions.height || 'auto'
        }}
        onMouseDown={handleMouseDown}
        onTouchStart={handleMouseDown}
      >
        <img
          src={image.src}
          alt="Original"
          onLoad={handleImageLoad}
          className="w-full h-auto pointer-events-none"
          style={{ maxWidth: '600px', display: 'block' }}
        />
        
        {/* Overlay divs */}
        {imageDimensions.width > 0 && (
          <>
            {/* Top overlay */}
            <div
              className="absolute bg-black/60 pointer-events-none"
              style={{
                top: 0,
                left: 0,
                right: 0,
                height: cropBox.y
              }}
            />
            
            {/* Bottom overlay */}
            <div
              className="absolute bg-black/60 pointer-events-none"
              style={{
                bottom: 0,
                left: 0,
                right: 0,
                height: imageDimensions.height - cropBox.y - cropBox.height
              }}
            />
            
            {/* Left overlay */}
            <div
              className="absolute bg-black/60 pointer-events-none"
              style={{
                left: 0,
                top: cropBox.y,
                height: cropBox.height,
                width: cropBox.x
              }}
            />
            
            {/* Right overlay */}
            <div
              className="absolute bg-black/60 pointer-events-none"
              style={{
                right: 0,
                top: cropBox.y,
                height: cropBox.height,
                width: imageDimensions.width - cropBox.x - cropBox.width
              }}
            />
            
            {/* Crop box */}
            <div
              className="absolute border-2 border-accent cursor-move"
              style={{
                left: cropBox.x,
                top: cropBox.y,
                width: cropBox.width,
                height: cropBox.height,
                touchAction: 'none'
              }}
            >
              {/* Corner handles */}
              {/* Top-left */}
              <div
                className="absolute w-3 h-3 bg-white border-2 border-accent rounded-full cursor-nwse-resize"
                style={{
                  left: -6,
                  top: -6,
                  touchAction: 'none'
                }}
              />
              
              {/* Top-right */}
              <div
                className="absolute w-3 h-3 bg-white border-2 border-accent rounded-full cursor-nesw-resize"
                style={{
                  right: -6,
                  top: -6,
                  touchAction: 'none'
                }}
              />
              
              {/* Bottom-left */}
              <div
                className="absolute w-3 h-3 bg-white border-2 border-accent rounded-full cursor-nesw-resize"
                style={{
                  left: -6,
                  bottom: -6,
                  touchAction: 'none'
                }}
              />
              
              {/* Bottom-right */}
              <div
                className="absolute w-3 h-3 bg-white border-2 border-accent rounded-full cursor-nwse-resize"
                style={{
                  right: -6,
                  bottom: -6,
                  touchAction: 'none'
                }}
              />
            </div>
          </>
        )}
      </div>
    </div>
  );
}
