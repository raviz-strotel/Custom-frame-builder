import React, { useState, useEffect, useRef } from 'react';
import { Paintbrush, Droplet, Pipette, Undo2, Redo2, ZoomIn, ZoomOut } from 'lucide-react';
import { Button } from '@/components/ui/button';
import ImageAdjustments from './ImageAdjustments';
import { DEFAULT_PALETTE, hexToRgb } from '@/utils/colorUtils';

export default function PixelStudio({ 
  pixelData, 
  onPixelDataChange, 
  adjustments, 
  onAdjustmentsChange, 
  onResetAdjustments 
}) {
  const [tool, setTool] = useState('paint');
  const [selectedColor, setSelectedColor] = useState(DEFAULT_PALETTE[0]);
  const [isDrawing, setIsDrawing] = useState(false);
  const [history, setHistory] = useState([]);
  const [historyIndex, setHistoryIndex] = useState(-1);
  const [zoom, setZoom] = useState(1);
  const [scale] = useState(16);
  
  const canvasRef = useRef(null);

  // Initialize history
  useEffect(() => {
    if (pixelData && history.length === 0) {
      saveHistory();
    }
  }, [pixelData]);

  // Draw canvas whenever pixelData or zoom changes
  useEffect(() => {
    if (pixelData) {
      drawCanvas();
    }
  }, [pixelData, zoom]);

  const drawCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    const size = 32;
    const displayScale = scale * zoom;
    
    canvas.width = size * displayScale;
    canvas.height = size * displayScale;
    
    ctx.imageSmoothingEnabled = false;
    
    // Draw each pixel as a rectangle
    for (let y = 0; y < size; y++) {
      for (let x = 0; x < size; x++) {
        const idx = (y * size + x) * 4;
        const r = pixelData.data[idx];
        const g = pixelData.data[idx + 1];
        const b = pixelData.data[idx + 2];
        
        ctx.fillStyle = `rgb(${r},${g},${b})`;
        ctx.fillRect(x * displayScale, y * displayScale, displayScale, displayScale);
      }
    }
    
    // Draw grid lines
    ctx.strokeStyle = 'rgba(0,0,0,0.15)';
    ctx.lineWidth = 1;
    for (let i = 0; i <= size; i++) {
      ctx.beginPath();
      ctx.moveTo(i * displayScale, 0);
      ctx.lineTo(i * displayScale, size * displayScale);
      ctx.stroke();
      
      ctx.beginPath();
      ctx.moveTo(0, i * displayScale);
      ctx.lineTo(size * displayScale, i * displayScale);
      ctx.stroke();
    }
  };

  const saveHistory = () => {
    const newData = new Uint8ClampedArray(pixelData.data);
    const newImageData = new ImageData(newData, 32, 32);
    const newHistory = history.slice(0, historyIndex + 1);
    newHistory.push(newImageData);
    setHistory(newHistory);
    setHistoryIndex(newHistory.length - 1);
  };

  const undo = () => {
    if (historyIndex > 0) {
      const newIndex = historyIndex - 1;
      setHistoryIndex(newIndex);
      onPixelDataChange(history[newIndex]);
    }
  };

  const redo = () => {
    if (historyIndex < history.length - 1) {
      const newIndex = historyIndex + 1;
      setHistoryIndex(newIndex);
      onPixelDataChange(history[newIndex]);
    }
  };

  const getCanvasPosition = (e) => {
    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();
    
    let clientX, clientY;
    if (e.touches && e.touches.length > 0) {
      clientX = e.touches[0].clientX;
      clientY = e.touches[0].clientY;
    } else {
      clientX = e.clientX;
      clientY = e.clientY;
    }
    
    const x = Math.floor((clientX - rect.left) / (scale * zoom));
    const y = Math.floor((clientY - rect.top) / (scale * zoom));
    
    return { x, y };
  };

  const paintPixel = (x, y) => {
    if (x < 0 || x >= 32 || y < 0 || y >= 32) return;
    
    const newData = new Uint8ClampedArray(pixelData.data);
    const idx = (y * 32 + x) * 4;
    const rgb = hexToRgb(selectedColor);
    
    if (rgb) {
      newData[idx] = rgb.r;
      newData[idx + 1] = rgb.g;
      newData[idx + 2] = rgb.b;
      onPixelDataChange(new ImageData(newData, 32, 32));
    }
  };

  const floodFill = (startX, startY) => {
    if (startX < 0 || startX >= 32 || startY < 0 || startY >= 32) return;
    
    const newData = new Uint8ClampedArray(pixelData.data);
    const startIdx = (startY * 32 + startX) * 4;
    const targetColor = { 
      r: newData[startIdx], 
      g: newData[startIdx + 1], 
      b: newData[startIdx + 2] 
    };
    const fillColor = hexToRgb(selectedColor);
    
    if (!fillColor) return;
    if (targetColor.r === fillColor.r && targetColor.g === fillColor.g && targetColor.b === fillColor.b) return;
    
    const stack = [[startX, startY]];
    const visited = new Set();
    
    while (stack.length > 0) {
      const [x, y] = stack.pop();
      const key = `${x},${y}`;
      if (visited.has(key) || x < 0 || x >= 32 || y < 0 || y >= 32) continue;
      
      const idx = (y * 32 + x) * 4;
      if (newData[idx] !== targetColor.r || newData[idx + 1] !== targetColor.g || newData[idx + 2] !== targetColor.b) continue;
      
      visited.add(key);
      newData[idx] = fillColor.r;
      newData[idx + 1] = fillColor.g;
      newData[idx + 2] = fillColor.b;
      
      stack.push([x + 1, y], [x - 1, y], [x, y + 1], [x, y - 1]);
    }
    
    onPixelDataChange(new ImageData(newData, 32, 32));
    saveHistory();
  };

  const pickColor = (x, y) => {
    if (x < 0 || x >= 32 || y < 0 || y >= 32) return;
    
    const idx = (y * 32 + x) * 4;
    const r = pixelData.data[idx];
    const g = pixelData.data[idx + 1];
    const b = pixelData.data[idx + 2];
    
    const hex = `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1).toUpperCase()}`;
    setSelectedColor(hex);
    setTool('paint');
  };

  const handleCanvasMouseDown = (e) => {
    e.preventDefault();
    const { x, y } = getCanvasPosition(e);
    
    if (tool === 'paint') {
      setIsDrawing(true);
      paintPixel(x, y);
    } else if (tool === 'fill') {
      floodFill(x, y);
    } else if (tool === 'pick') {
      pickColor(x, y);
    }
  };

  const handleCanvasMouseMove = (e) => {
    if (!isDrawing || tool !== 'paint') return;
    e.preventDefault();
    const { x, y } = getCanvasPosition(e);
    paintPixel(x, y);
  };

  const handleCanvasMouseUp = () => {
    if (isDrawing) {
      saveHistory();
      setIsDrawing(false);
    }
  };

  const handleZoomIn = () => {
    setZoom(prev => Math.min(prev + 0.25, 3));
  };

  const handleZoomOut = () => {
    setZoom(prev => Math.max(prev - 0.25, 0.5));
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
      {/* Left sidebar - Image Adjustments */}
      <div className="lg:col-span-1">
        <ImageAdjustments
          adjustments={adjustments}
          onAdjustmentsChange={onAdjustmentsChange}
          onReset={onResetAdjustments}
        />
      </div>

      {/* Main canvas area */}
      <div className="lg:col-span-3">
        <div className="bg-white rounded-xl border border-border p-6 shadow-sm">
          {/* Header with zoom controls */}
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-text-primary">Pixel Art (32x32)</h3>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={handleZoomOut}
                disabled={zoom <= 0.5}
              >
                <ZoomOut className="w-4 h-4" />
              </Button>
              <span className="text-sm font-mono text-text-primary min-w-[60px] text-center">
                {Math.round(zoom * 100)}%
              </span>
              <Button
                variant="outline"
                size="sm"
                onClick={handleZoomIn}
                disabled={zoom >= 3}
              >
                <ZoomIn className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {/* Canvas container with scroll */}
          <div className="overflow-auto mb-4 border border-border rounded-lg bg-background-secondary p-4">
            <canvas
              ref={canvasRef}
              className="mx-auto"
              style={{ imageRendering: 'pixelated', touchAction: 'none' }}
              onMouseDown={handleCanvasMouseDown}
              onMouseMove={handleCanvasMouseMove}
              onMouseUp={handleCanvasMouseUp}
              onMouseLeave={handleCanvasMouseUp}
              onTouchStart={handleCanvasMouseDown}
              onTouchMove={handleCanvasMouseMove}
              onTouchEnd={handleCanvasMouseUp}
            />
          </div>

          {/* Tools bar */}
          <div className="flex items-center gap-2 mb-4 flex-wrap">
            <Button
              variant={tool === 'paint' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setTool('paint')}
              className="gap-2"
              data-testid="paint-tool"
            >
              <Paintbrush className="w-4 h-4" />
              Paint
            </Button>
            <Button
              variant={tool === 'fill' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setTool('fill')}
              className="gap-2"
              data-testid="fill-tool"
            >
              <Droplet className="w-4 h-4" />
              Fill
            </Button>
            <Button
              variant={tool === 'pick' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setTool('pick')}
              className="gap-2"
              data-testid="pick-tool"
            >
              <Pipette className="w-4 h-4" />
              Pick
            </Button>

            <div className="w-px h-8 bg-border mx-2" />

            <Button
              variant="outline"
              size="sm"
              onClick={undo}
              disabled={historyIndex <= 0}
              className="gap-2"
              data-testid="undo-btn"
            >
              <Undo2 className="w-4 h-4" />
              Undo
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={redo}
              disabled={historyIndex >= history.length - 1}
              className="gap-2"
              data-testid="redo-btn"
            >
              <Redo2 className="w-4 h-4" />
              Redo
            </Button>
          </div>

          {/* Color palette */}
          <div>
            <h4 className="text-sm font-medium text-text-secondary mb-3">Color Palette</h4>
            <div className="grid grid-cols-10 gap-2 mb-3">
              {DEFAULT_PALETTE.map((color, index) => (
                <button
                  key={index}
                  className={`w-full aspect-square rounded border-2 transition-all ${
                    selectedColor === color ? 'border-accent scale-110' : 'border-transparent'
                  }`}
                  style={{ backgroundColor: color }}
                  onClick={() => setSelectedColor(color)}
                  title={color}
                />
              ))}
            </div>
            <div className="flex items-center gap-2">
              <span className="text-sm text-text-secondary">Selected:</span>
              <div
                className="w-8 h-8 rounded border-2 border-border"
                style={{ backgroundColor: selectedColor }}
              />
              <span className="text-sm font-mono text-text-primary">{selectedColor}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
