import React from 'react';
import { RotateCcw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';

export default function ImageAdjustments({ adjustments, onAdjustmentsChange, onReset }) {
  const handleChange = (key, value) => {
    onAdjustmentsChange({ ...adjustments, [key]: value[0] });
  };

  return (
    <div className="bg-white rounded-xl border border-border p-6 shadow-sm">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold text-text-primary">Image Adjustments</h3>
        <Button
          variant="outline"
          size="sm"
          onClick={onReset}
          className="gap-2"
        >
          <RotateCcw className="w-4 h-4" />
          Reset
        </Button>
      </div>

      <div className="space-y-6">
        {/* Brightness */}
        <div>
          <div className="flex justify-between items-center mb-2">
            <label className="text-sm font-medium text-text-secondary">Brightness</label>
            <span className="text-sm font-mono text-text-primary">{adjustments.brightness}</span>
          </div>
          <Slider
            value={[adjustments.brightness]}
            onValueChange={(value) => handleChange('brightness', value)}
            min={-100}
            max={100}
            step={1}
          />
        </div>

        {/* Contrast */}
        <div>
          <div className="flex justify-between items-center mb-2">
            <label className="text-sm font-medium text-text-secondary">Contrast</label>
            <span className="text-sm font-mono text-text-primary">{adjustments.contrast}</span>
          </div>
          <Slider
            value={[adjustments.contrast]}
            onValueChange={(value) => handleChange('contrast', value)}
            min={-100}
            max={100}
            step={1}
          />
        </div>

        {/* Saturation */}
        <div>
          <div className="flex justify-between items-center mb-2">
            <label className="text-sm font-medium text-text-secondary">Saturation</label>
            <span className="text-sm font-mono text-text-primary">{adjustments.saturation}</span>
          </div>
          <Slider
            value={[adjustments.saturation]}
            onValueChange={(value) => handleChange('saturation', value)}
            min={-100}
            max={100}
            step={1}
          />
        </div>

        {/* Hue Shift */}
        <div>
          <div className="flex justify-between items-center mb-2">
            <label className="text-sm font-medium text-text-secondary">Hue Shift</label>
            <span className="text-sm font-mono text-text-primary">{adjustments.hue}°</span>
          </div>
          <Slider
            value={[adjustments.hue]}
            onValueChange={(value) => handleChange('hue', value)}
            min={0}
            max={360}
            step={1}
          />
        </div>
      </div>

      <p className="text-xs italic text-text-muted mt-6">
        Adjustments apply in real-time
      </p>
    </div>
  );
}
